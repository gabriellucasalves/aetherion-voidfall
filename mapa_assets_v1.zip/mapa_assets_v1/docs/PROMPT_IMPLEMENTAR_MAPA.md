# NOTA DE ARTE (mapa_assets_v1)

Use como fundo preferencial: `../map_island_bg_clean.png` (herói assado removido; ver `../compare/` — patch de grama imperfeito).
Overlays prontos em `../overlays/` (status transparente; não substituem o nó base).
Coordenadas aproximadas: `../map_art_coords.json` + `../guides/route_guide_annotated.png`.
Herói overworld: **não** está neste pack — usar sprites atuais do projeto.
Fundo = PNG estático não-nativo Aseprite; Fase 2/3 só conceito.

---

# PROMPT ÚNICO — Implementar mapa-mundo após Fase 1 (Cursor local)

Cola este arquivo inteiro no Cursor **no Mac**, projeto  
`/Users/gabriellucas/Desktop/Aetherion_Atmos_V1`.  
Autor: implementação local + QA Play/WebGL local.  
**Proibido neste sprint:** push, deploy Vercel, merge em `main`, `reset --hard`, limpar worktree sujo, On-Demand/CloudAgent pesado, clonar repos remotos só para “descobrir”.

O ZIP que acompanha isto é **spec + JPG de referência**, não a implementação.

---

## 0. Antes de qualquer escrita

1. `git status` e `git branch` no worktree `Aetherion_Atmos_V1`.  
   - Se houver mudanças sujas: **não sobrescrever**; commitar em branch de trabalho ou stash consciente.  
   - Confirme a branch atual; **não** faça checkout destrutivo. Crie/use branch tipo `feature/overworld-mapa-pos-f1` a partir do HEAD atual se fizer sentido.
2. **Descubra no código real** (não invente nomes):
   - Como a Fase 1 detecta **conclusão verdadeira** (ondas obrigatórias + saída/portal). Procure em torno de `GroundT1Controller`, `SimpleEnemySpawner`, `F1ExitPortal` e equivalentes **que existirem** no projeto.
   - Como herói atual / aparência / id são escolhidos e persistidos (Boot, seleção, `HeroAppearance`, PlayerPrefs, etc.).
   - Como inimigos **atuais** da Fase 1 estão (direção pure 16-bit recente). **Não reverter** cenário/inimigos para Atmos antigo, V4 híbrido ou slice do JPG V5.
3. Relatório curto no fim: APIs/métodos **reais** encontrados + gaps (Fase 2/3/boss existem ou não).

---

## 1. Referência visual (aprovada) — regras de arte

Arquivo: `aetherion_worldmap_conceito_ilha_3fases.jpg` (16:9, conceito estático aprovado: “perfeitooo”).

### Obrigatório — limpeza do herói assado
Inspecione o JPG: há um **cavaleiro vermelho/preto minúsculo já pintado** na trilha perto do nó 1.  
**Proibido** usar o JPG inteiro como fundo jogável com esse pixel-herói.

Entregáveis de arte (faça de verdade; **não finja** que layers/sprites já existem):

1. **`map_island_bg` (placa limpa):** redesenho/limpeza **pixel art nativa** fiel ao conceito (mesma pegada pure 16-bit: clusters, paleta slate/lavanda/musgo/teal/magenta, luz creme-pêssego), **sem** o cavaleiro assado, **sem** HUD, **sem** slice semi-realista do JPG como “foto colada”.  
   - Números 1/2/3 nos nós circulares: ou (a) ficam na placa alinhados a âncoras runtime, ou (b) são sprites/UI de nó separados — mas posições do path/nós no runtime devem **bater** com a arte.
2. **`hero_overworld`:** sprite(s) **separado(s)** animado(s) (idle/walk mínimo), escala consistente com o mapa, derivado dos **sprites atuais do herói jogável** do projeto (Guerreiro/Arqueiro/Mago conforme id salvo) — **não** Mario, **não** segundo cavaleiro duplicado do JPG.
3. Opcional: overlays de nós (locked/cleared/available) se ajudar legibilidade.

Import Unity: Sprite, **Point**, **sem mipmaps**, Compression **None**.  
**Não** force PPU global do projeto; escolha PPU do mapa coerente com a cena do overworld e com o Pixel Perfect / apresentação **já existente** (não imponha 384 “no escuro”). Aspecto 16:9 do mapa legível; Canvas em **safe area** — a barra do personagem **não** pode ficar cortada; **não** refatore HUD inteiro neste sprint (só o necessário para o mapa não cortar UI).

Camadas transparentes **só se** você as produzir; não declare atlas/layers inexistentes.

---

## 2. Grafo do overworld (exatamente 3 nós)

| Nó | Papel | Conteúdo visual (conceito) |
|---|---|---|
| 1 | Fase 1 — santuário alienígena | Flora rosa/teal, início da trilha |
| 2 | Fase 2 — ruínas (proposta) | Arco/colunas, runa ciano |
| 3 | Fase 3 — fortaleza / boss (proposta) | Fortaleza escura no alto-direita |

- **Uma** trilha pedra/terra contínua ligando 1–2–3 (backtrack permitido).  
- Sem nós extras.  
- Landmarks **não** ocluem a trilha.

### Controles
- A/D ou setas: mover ao longo da rota.  
- W/S opcional só se houver escolha de rota real.  
- Enter ou Espaço: confirmar entrada na fase do nó atual.  
- Debounce / trava: **zero** double-submit (não abrir duas loads).

### Regras de acesso
- Nó bloqueado: não entra.  
- Fase inexistente (2 ou 3): UI **“Em desenvolvimento”** — **não** carregar cena inventada, **não** duplicar Stage1, **não** fingir boss.  
- Fases limpas: replay permitido.  
- Morte **não** desbloqueia próximo nó.  
- Pause / foco de input: mapa e fases não “comem” input um do outro.

---

## 3. Fluxo de progresso (obrigatório)

1. Jogador está na Fase 1.  
2. Conclusão **verdadeira** via fluxo **já existente** (ondas exigidas → portal/saída existente — use o que o código real fizer).  
3. Transição **exatamente uma vez** para a cena/estado Overworld.  
4. Persistir: Fase 1 **cleared**; Fase 2 **unlocked**; herói no nó 1 (pode andar até 2).  
5. Ao completar Fase 2 (quando existir): desbloqueia 3.  
6. Boss/Fase 3: só quando a cena/encontro **real** existir; morte do boss (confirmação real) marca **jogo completo**. Se não existir: gap honesto + “Em desenvolvimento”.

**Não** implemente agora combate completo de 2 fases novas nem boss inventado — só **integração do mapa** + hooks. Liste no relatório o que falta para Fase 2/3/boss.

---

## 4. Persistência (WebGL-safe)

- PlayerPrefs (ou wrapper já usado no projeto), schema **versionado** (`map_save_v1` ou similar).  
- Campos mínimos: version, heroId, flags cleared/unlocked por nó (1..3), nó atual, flag “jogo completo” se aplicável.  
- **Não** serializar arrays vivos de gameplay (inimigos em cena, etc.).  
- **Não** sobrescrever saves automaticamente sem regra clara (ex.: só escrever em checkpoints: clear de fase, unlock, entrada confirmada).  
- Reload / reabrir WebGL local: progresso e hero id sobrevivem.

---

## 5. Direção artística a preservar

- Manter cenário **pure 16-bit** e inimigos **já atualizados** da Fase 1.  
- Não voltar para Atmos chapado, tint-only, nem JPG conceito V5 fatiado.  
- Âncoras: flora rosa/willow + parasol teal, ardósia facetada, luz creme-pêssego, mármore/runas/ciano.

---

## 6. QA — capturas reais (Play Mode; WebGL local se o pipeline existir, **sem deploy**)

Tire e anexe prints **reais** (diga se algum ficou sem testar):

1. Antes de completar Fase 1 — sem mapa.  
2. Logo após conclusão Fase 1 — mapa, nó 1 limpo, nó 2 unlocked.  
3. Andando na trilha.  
4. Destino locked / “Em desenvolvimento”.  
5. Save → reload (progresso ok).  
6. Replay fase limpa + regressão pause / morte / portal da Fase 1.

Checklist: marque só o que passou de verdade. Relatório final: arquivos **modificados de fato**, prints, gaps Fase 2/3/boss, se está pronto para um **prompt separado** GitHub/Vercel (ainda não executar).

---

## 7. Entrega da implementação (resposta ao humano)

- Branch usada + `git status` limpo ou lista do que ficou pendente.  
- Lista de files tocados.  
- Como testar no Editor (cena/boot).  
- Confirmação: sem push/deploy/merge main.  
- Prontidão: **não** diga “pronto pra Vercel” sem as 6 capturas.

Fim. Um tiro de implementação local. Spec + JPG do ZIP = referência; código e assets nativos = sua entrega.
